% Default prolog startup file for Poplog users
% Copied from /bham/common/system/templates/user.poplog/Poplib/init.pl
% A.Sloman Sun Nov 12 12:34:09 GMT 1995

:-library(useful).
