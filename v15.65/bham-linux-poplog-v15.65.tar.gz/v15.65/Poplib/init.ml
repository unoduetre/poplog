;;;   @(#)cs.bham: init.ml, v 1.1 92/04/26 04:26:16 aqw
;;; Now in /bham/common/system/templates/user.poplog//Poplib/init.ml

pervasive Useful Lists;
