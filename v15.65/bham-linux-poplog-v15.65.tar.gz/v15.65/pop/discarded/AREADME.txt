Files in the $usepop/pop/discarded directory are early versions of
files that were updated at Birmingham and installed in poplog in
their place.

Aaron Sloman
http://www.cs.bham.ac.uk/~axs/
