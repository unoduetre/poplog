/*  --- Copyright University of Sussex 1986.  All rights reserved. ---------
 *  File:			C.all/plog/lib/popsetq.pl
 *  Author:         Contents removed by Robert Duncan, 19 Jan. 1988
 */


/**************************************************************************

	This library file has been withdrawn.

	All the predicates which used to be defined here are now part of the
	system.

	For details, see:

		PLOGHELP * PROLOG_SETQ
		PLOGHELP * PROLOG_VAL

**************************************************************************/
