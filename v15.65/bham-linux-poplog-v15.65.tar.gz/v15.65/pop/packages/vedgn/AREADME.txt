http://www.cs.bham.ac.uk/research/poplog/vedgn/AREADME.txt
$usepop/pop/packages/AREADME.txt

Provides facilities to allow VED to be used for accessing news server
using the environment variable $NNTPSERVER

See
    help/ved_gn
    help/ved_postnews

Supersedes old versions including ved_net

To make all this available give the pop11 command

    uses vedgn
