$usepop/pop/packages/vedutils/AREADME.txt


The files in the directory
    $usepop/pop/packages/vedutils

provide a number of extensions to the utilities included in

    $usepop/pop/lib/ved

Some of these were developed at Birmingham, and were not part of the
Poplog system as distributed by ISL.

They were previously included in 'extra' packages to be added to
$local directories in Poplog. They are now part of the Poplog
packages system instead.

Feel free to suggest additions, corrections, improvements.

Aaron Sloman
3 Jul 2009
http://www.cs.bham.ac.uk/~axs
