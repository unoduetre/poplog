$usepop/pop/packages/teaching/AREADME.txt
Aaron Sloman
3 Jul 2009

When poplog was reorgahised to include a tree of packages
to replace the local directories (version 15.6 in 2005)
one of the packages created was this one

    $usepop/pop/packages/teaching/

The idea was to separate from the main pop-11 program and
documentation files those that were not concerned with general
purpose programming or AI techniques, but introduced tutorials (with
accompanying sofware) on particular AI topics or possible
introductory programming projects or exercises.

At the same time new teaching materials that had been developed at
Birmingham that were not in the version of Poplog sold by ISL were
added either here or in the central files.

There are still things left in the main/central pop-11 files

    $usepop/pop/lib/lib
    $usepop/pop/lib/auto
    $usepop/pop/lib/ved
    $usepop/pop/teach
    $usepop/pop/help

that arguably should be moved to the 'teaching' package. However,
that can be left as a non-urgent task.

Please feel free to report problems, or propose additions to the
teaching directory.
